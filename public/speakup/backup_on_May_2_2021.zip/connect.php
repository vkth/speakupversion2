<?php

// $conn = mysqli_connect("localhost", "root", "", "speakup");
//$conn = mysqli_connect(
//    "ec2-52-21-252-142.compute-1.amazonaws.com",
//    "fytmxcadqxmhxv",
//    "c379347585a8ec0dc7d94d5758bd4bb4e3f80df9971099c316903012d92fa95b",
//    "db41qemd6gkc0g",
//    "5432");
$conn = mysqli_connect(
   "remotemysql.com",
   "fKjE0CChQb",
   "fiDmb2Jzyd",
   "fKjE0CChQb",
   "3306");
?>